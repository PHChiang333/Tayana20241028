# CKEditor 5 sample

Thank you for downloading the sample. To run it, start a web server (`nginx`, `caddy` or any other) that will serve the file.

Want to test more features? Get started with CKEditor 5 Builder 🚀

With [CKEditor’s interactive builder](https://ckeditor.com/ckeditor-5/builder/), select:

* The features you need.
* Your preferred framework (React, Angular, Vue, or Vanilla JS).
* Your preferred distribution method (CDN or npm).

You’ll get ready-to-use code snippets, tailored to your needs.
